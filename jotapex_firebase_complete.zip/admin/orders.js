import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.7.0/firebase-app.js';
import { getFirestore, collection, getDocs, doc, updateDoc } from 'https://www.gstatic.com/firebasejs/10.7.0/firebase-firestore.js';
import { getAuth, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/10.7.0/firebase-auth.js';
const firebaseConfig = { apiKey: "AIzaSyDX0U-MCwbd49V7Hl3YNsYqRb4noaS4usY", authDomain: "jotapex-store.firebaseapp.com", projectId: "jotapex-store", storageBucket: "jotapex-store.firebasestorage.app", messagingSenderId: "819257296028", appId: "1:819257296028:web:d4b9daf610ad2f8a5959" };
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);
onAuthStateChanged(auth, user=>{ if(!user) window.location.href='login.html'; else load(); });
async function load(){ const snaps = await getDocs(collection(db,'orders')); const el = document.getElementById('orders'); el.innerHTML=''; snaps.forEach(s=>{ const data = s.data(); const div = document.createElement('div'); div.className='card'; div.innerHTML = `<b>Pedido ${s.id}</b> - ${data.email} - R$${data.amount} - Status: ${data.status} <div><button onclick="setStatus('${s.id}','paid')">Marcar Pago</button></div>`; el.appendChild(div); }); }
window.setStatus = async (id, st) => { await updateDoc(doc(db,'orders',id), { status: st }); load(); };