import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.7.0/firebase-app.js';
import { getAuth, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/10.7.0/firebase-auth.js';
import { getFirestore, collection, getDocs } from 'https://www.gstatic.com/firebasejs/10.7.0/firebase-firestore.js';
const firebaseConfig = { apiKey: "AIzaSyDX0U-MCwbd49V7Hl3YNsYqRb4noaS4usY", authDomain: "jotapex-store.firebaseapp.com", projectId: "jotapex-store", storageBucket: "jotapex-store.firebasestorage.app", messagingSenderId: "819257296028", appId: "1:819257296028:web:d4b9daf610ad2f8a5959" };
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
onAuthStateChanged(auth, async user=>{
  if(!user){ alert('Acesso restrito'); window.location.href='login.html'; return; }
  const idt = await user.getIdTokenResult();
  if(!idt.claims || !idt.claims.admin){ alert('Somente admins'); window.location.href='login.html'; return; }
  const snaps = await getDocs(collection(db,'orders'));
  const labels=[]; const data=[];
  snaps.forEach(s=>{ labels.push(new Date(s.data().createdAt).toLocaleString()); data.push(s.data().amount || 0); });
  const ctx = document.getElementById('chart').getContext('2d');
  new Chart(ctx,{type:'line',data:{labels,data}});
});