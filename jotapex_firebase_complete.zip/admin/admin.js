import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.7.0/firebase-app.js';
import { getAuth, signInWithEmailAndPassword } from 'https://www.gstatic.com/firebasejs/10.7.0/firebase-auth.js';
const firebaseConfig = {
  apiKey: "AIzaSyDX0U-MCwbd49V7Hl3YNsYqRb4noaS4usY",
  authDomain: "jotapex-store.firebaseapp.com",
  projectId: "jotapex-store",
  storageBucket: "jotapex-store.firebasestorage.app",
  messagingSenderId: "819257296028",
  appId: "1:819257296028:web:d4b9daf610ad2f8a5959"
};
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

document.getElementById('login').onclick = async ()=>{
  const email = document.getElementById('email').value;
  const pass = document.getElementById('password').value;
  try{
    await signInWithEmailAndPassword(auth, email, pass);
    window.location.href = 'dashboard.html';
  }catch(e){ alert('Erro: '+e.message); }
};