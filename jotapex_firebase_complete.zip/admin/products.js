import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.7.0/firebase-app.js';
import { getFirestore, collection, addDoc, getDocs, doc, deleteDoc } from 'https://www.gstatic.com/firebasejs/10.7.0/firebase-firestore.js';
import { getAuth, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/10.7.0/firebase-auth.js';
const firebaseConfig = { apiKey: "AIzaSyDX0U-MCwbd49V7Hl3YNsYqRb4noaS4usY", authDomain: "jotapex-store.firebaseapp.com", projectId: "jotapex-store", storageBucket: "jotapex-store.firebasestorage.app", messagingSenderId: "819257296028", appId: "1:819257296028:web:d4b9daf610ad2f8a5959" };
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);
onAuthStateChanged(auth, user=>{ if(!user) window.location.href='login.html'; else load(); });
async function load(){ const snaps = await getDocs(collection(db,'products')); const list = document.getElementById('list'); list.innerHTML=''; snaps.forEach(s=>{ const d = document.createElement('div'); d.className='card'; d.innerHTML = `<b>${s.data().name}</b> — R$${s.data().price} <button onclick="del('${s.id}')">Excluir</button>`; list.appendChild(d); }); }
window.create = async ()=>{ const name = document.getElementById('name').value; const price = parseFloat(document.getElementById('price').value); const emoji = document.getElementById('emoji').value || '📦'; await addDoc(collection(db,'products'), { name, price, emoji }); load(); };
window.del = async (id)=>{ await deleteDoc(doc(db,'products',id)); load(); };
document.getElementById('create').onclick = ()=> window.create();