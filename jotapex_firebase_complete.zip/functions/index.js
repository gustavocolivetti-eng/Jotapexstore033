const functions = require("firebase-functions");
const admin = require("firebase-admin");
const axios = require("axios");
admin.initializeApp();
const db = admin.firestore();
const MP_BASE = 'https://api.mercadopago.com';
exports.createPix = functions.https.onRequest(async (req, res) => {
  try{
    const { orderId, amount, email } = req.body;
    if(!orderId || !amount) return res.status(400).json({ error: 'orderId and amount required' });
    const payload = { transaction_amount: Number(amount), payment_method_id: "pix", external_reference: orderId, payer: { email: email || "no-reply@example.com" } };
    const token = functions.config().mercadopago?.token;
    if(!token) return res.status(500).json({ error: 'MercadoPago token not configured. See README.' });
    const r = await axios.post(MP_BASE + '/v1/payments', payload, { headers: { Authorization: 'Bearer ' + token, 'Content-Type':'application/json' } });
    const data = r.data;
    await db.collection('orders').doc(orderId).set({ mp_payment_id: data.id, status: data.status, payment: data }, { merge: true });
    res.json({ ok: true, payment: data });
  }catch(e){ console.error(e.response ? e.response.data : e.message); res.status(500).json({ error: e.response ? e.response.data : e.message }); }
});
exports.mpWebhook = functions.https.onRequest(async (req, res) => {
  try{
    const body = req.body;
    const paymentId = body?.data?.id || body?.id;
    if(!paymentId) return res.status(400).send('no id');
    const token = functions.config().mercadopago?.token;
    const r = await axios.get(MP_BASE + `/v1/payments/${paymentId}`, { headers: { Authorization: 'Bearer ' + token } });
    const payment = r.data;
    const external_reference = payment.external_reference;
    const status = payment.status;
    if(external_reference){
      await db.collection('orders').doc(external_reference).set({ status: status, mp_payment_id: paymentId, payment }, { merge: true });
    } else {
      const q = await db.collection('orders').where('mp_payment_id','==',paymentId).get();
      q.forEach(doc => doc.ref.set({ status: status, payment }, { merge: true }));
    }
    res.status(200).send('ok');
  }catch(e){ console.error(e); res.status(500).send('error'); }
});
