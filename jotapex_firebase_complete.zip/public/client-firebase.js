import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.7.0/firebase-app.js';
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword } from 'https://www.gstatic.com/firebasejs/10.7.0/firebase-auth.js';
import { getFirestore, collection, getDocs, addDoc, doc, getDoc } from 'https://www.gstatic.com/firebasejs/10.7.0/firebase-firestore.js';

const firebaseConfig = {
  "apiKey": "AIzaSyDX0U-MCwbd49V7Hl3YNsYqRb4noaS4usY",
  "authDomain": "jotapex-store.firebaseapp.com",
  "projectId": "jotapex-store",
  "storageBucket": "jotapex-store.firebasestorage.app",
  "messagingSenderId": "819257296028",
  "appId": "1:819257296028:web:d4b9daf610ad2f8a5959"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const PRODUCTS_EL = document.getElementById('products');
const CART_ITEMS = document.getElementById('cart-items');
const TOTAL_EL = document.getElementById('total');
const CART_COUNT = document.getElementById('cart-count');
let CART = [];

async function loadProducts(){
  const snap = await getDocs(collection(db,'products'));
  if(snap.empty){ PRODUCTS_EL.innerHTML = '<div class="card">Nenhum produto encontrado. Use o painel admin para inserir produtos.</div>'; return; }
  PRODUCTS_EL.innerHTML = '';
  snap.forEach(docSnap => {
    const p = docSnap.data();
    const el = document.createElement('div');
    el.className = 'card';
    el.innerHTML = `\n      <div class="product-img">${p.emoji || '📦'}</div>\n      <div style="margin-top:8px;font-weight:700">${p.name}</div>\n      <div style="color:var(--muted)">R$${p.price.toFixed(2)}</div>\n      <div style="margin-top:8px"><button class="btn add" data-id="${docSnap.id}">Adicionar</button></div>\n    `;
    PRODUCTS_EL.appendChild(el);
  });
  document.querySelectorAll('.add').forEach(btn=> btn.onclick = ()=> addToCart(btn.dataset.id) );
}

async function addToCart(productId){
  const pdoc = await getDoc(doc(db,'products',productId));
  if(!pdoc.exists()) return alert('Produto não encontrado');
  const p = pdoc.data();
  CART.push({ id: productId, name: p.name, price: p.price });
  renderCart();
}

function renderCart(){
  if(CART.length===0) CART_ITEMS.textContent = 'Nenhum item';
  else {
    CART_ITEMS.innerHTML = '';
    CART.forEach(it=> { const d = document.createElement('div'); d.textContent = `${it.name} — R$${it.price.toFixed(2)}`; CART_ITEMS.appendChild(d); });
  }
  const tot = CART.reduce((s,i)=>s+i.price,0);
  TOTAL_EL.textContent = 'R$' + tot.toFixed(2);
  CART_COUNT.textContent = CART.length;
}

document.getElementById('checkout').addEventListener('click', async ()=>{
  if(CART.length===0) return alert('Carrinho vazio');
  const amount = CART.reduce((s,i)=>s+i.price,0);
  const email = prompt('Digite seu e-mail para receber o comprovante:', '');
  if(!email) return;
  const orderRef = await addDoc(collection(db,'orders'), { items: CART, amount, status: 'pending', email, createdAt: new Date().toISOString() });
  const res = await fetch('/createPix', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ orderId: orderRef.id, amount, email })
  });
  const data = await res.json();
  if(data.ok){
    const win = window.open('', '_blank');
    win.document.write('<h2>PIX Gerado</h2>');
    if(data.payment.qr_code_base64){
      win.document.write('<img src="data:image/png;base64,' + data.payment.qr_code_base64 + '" />');
    } else if(data.payment.qr_code){
      const url = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' + encodeURIComponent(data.payment.qr_code);
      win.document.write('<img src="' + url + '" />');
    }
    win.document.write('<p>Status: ' + data.payment.status + '</p>');
    alert('PIX gerado — confira a nova janela (ou o ticket_url)');
  } else {
    alert('Erro ao gerar PIX: ' + (data.error || JSON.stringify(data)));
  }
});

// login modal logic
const loginModal = document.getElementById('login-modal');
document.getElementById('btn-login').onclick = ()=> loginModal.classList.remove('hidden');
document.getElementById('close-login').onclick = ()=> loginModal.classList.add('hidden');

document.getElementById('login-btn').onclick = async ()=> {
  const email = document.getElementById('email').value;
  const pass = document.getElementById('password') ? document.getElementById('password').value : document.getElementById('password')?.value;
  try{
    await signInWithEmailAndPassword(auth, email, pass);
    alert('Logado');
    loginModal.classList.add('hidden');
  }catch(e){ alert('Erro login: ' + e.message); }
};

onAuthStateChanged(auth, user=>{ if(user) document.getElementById('btn-login').textContent = 'Sair'; });

loadProducts();
renderCart();
